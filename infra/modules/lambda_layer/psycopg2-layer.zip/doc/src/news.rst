.. index::
    single: Release notes
    single: News

.. _news:

Release notes
=============

.. include:: ../../NEWS
